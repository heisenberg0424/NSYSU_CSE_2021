#!/bin/bash -x
cd uva$1
zip B075040041-鄭煥榮-$1.zip *.png *.txt uva*.cpp 
